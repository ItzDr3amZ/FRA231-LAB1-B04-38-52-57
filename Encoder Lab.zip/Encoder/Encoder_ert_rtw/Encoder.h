/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: Encoder.h
 *
 * Code generated for Simulink model 'Encoder'.
 *
 * Model version                  : 1.126
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Fri Nov  1 04:59:57 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef Encoder_h_
#define Encoder_h_
#ifndef Encoder_COMMON_INCLUDES_
#define Encoder_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "math.h"
#include "main.h"
#endif                                 /* Encoder_COMMON_INCLUDES_ */

#include "Encoder_types.h"
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWExtModeInfo
#define rtmGetRTWExtModeInfo(rtm)      ((rtm)->extModeInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                (&(rtm)->Timing.taskTime0)
#endif

/* Block signals for system '<S12>/Digital Port Read' */
typedef struct {
  boolean_T DigitalPortRead;           /* '<S12>/Digital Port Read' */
} B_DigitalPortRead_Encoder_T;

/* Block states (default storage) for system '<S12>/Digital Port Read' */
typedef struct {
  stm32cube_blocks_DigitalPortR_T obj; /* '<S12>/Digital Port Read' */
  boolean_T objisempty;                /* '<S12>/Digital Port Read' */
} DW_DigitalPortRead_Encoder_T;

/* Block signals (default storage) */
typedef struct {
  real_T d_PULSES_X4;                  /* '<Root>/X4' */
  real_T PULSES_ALL_X4;                /* '<Root>/X4' */
  real_T AngularVelocity_X4;           /* '<Root>/X4' */
  real_T AngularPosition_X4;           /* '<Root>/X4' */
  real_T d_PULSES_X2;                  /* '<Root>/X2' */
  real_T PULSES_ALL_X2;                /* '<Root>/X2' */
  real_T AngularVelocity_X2;           /* '<Root>/X2' */
  real_T AngularPosition_X2;           /* '<Root>/X2' */
  real_T d_PULSES_X1;                  /* '<Root>/X1' */
  real_T PULSES_ALL_X1;                /* '<Root>/X1' */
  real_T AngularVelocity_X1;           /* '<Root>/X1' */
  real_T AngularPosition_X1;           /* '<Root>/X1' */
  real_T Polling_PULSES_X4_all;        /* '<Root>/POLLING_X4' */
  real_T Polling_AngularPosition_X4;   /* '<Root>/POLLING_X4' */
  real_T Polling_d_PULSES_X4;          /* '<Root>/POLLING_X4' */
  real_T Polling_AngularVelosity_X4;   /* '<Root>/POLLING_X4' */
  real_T Polling_PULSES_X2_all;        /* '<Root>/POLLING_X2' */
  real_T Polling_AngularPosition_X2;   /* '<Root>/POLLING_X2' */
  real_T Polling_d_PULSES_X2;          /* '<Root>/POLLING_X2' */
  real_T Polling_AngularVelosity_X2;   /* '<Root>/POLLING_X2' */
  real_T Polling_PULSES_X1_all;        /* '<Root>/POLLING_X1' */
  real_T Polling_AngularPosition_X1;   /* '<Root>/POLLING_X1' */
  real_T Polling_d_PULSES_X1;          /* '<Root>/POLLING_X1' */
  real_T Polling_AngularVelosity_X1;   /* '<Root>/POLLING_X1' */
  uint32_T PULSES_X4;                  /* '<Root>/Encoder5' */
  uint32_T PULSES_X2;                  /* '<Root>/Encoder4' */
  uint32_T PULSES_X1;                  /* '<Root>/Encoder2' */
  boolean_T DigitalPortRead_g;         /* '<S16>/Digital Port Read' */
  boolean_T DigitalPortRead_m;         /* '<S14>/Digital Port Read' */
  B_DigitalPortRead_Encoder_T DigitalPortRead_o;/* '<S12>/Digital Port Read' */
  B_DigitalPortRead_Encoder_T DigitalPortRead;/* '<S12>/Digital Port Read' */
} B_Encoder_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  stm32cube_blocks_EncoderBlock_T obj; /* '<Root>/Encoder5' */
  stm32cube_blocks_EncoderBlock_T obj_b;/* '<Root>/Encoder4' */
  stm32cube_blocks_EncoderBlock_T obj_o;/* '<Root>/Encoder2' */
  real_T PULSES_pass;                  /* '<Root>/X4' */
  real_T PULSES_ALL;                   /* '<Root>/X4' */
  real_T PULSES_pass_f;                /* '<Root>/X2' */
  real_T PULSES_ALL_i;                 /* '<Root>/X2' */
  real_T PULSES_pass_g;                /* '<Root>/X1' */
  real_T PULSES_ALL_j;                 /* '<Root>/X1' */
  real_T pass_A;                       /* '<Root>/POLLING_X4' */
  real_T pass_B;                       /* '<Root>/POLLING_X4' */
  real_T Polling_PULSES_X4;            /* '<Root>/POLLING_X4' */
  real_T Polling_PULSES_X4_d_all;      /* '<Root>/POLLING_X4' */
  real_T pass_A_g;                     /* '<Root>/POLLING_X2' */
  real_T pass_B_e;                     /* '<Root>/POLLING_X2' */
  real_T Polling_PULSES_X2;            /* '<Root>/POLLING_X2' */
  real_T Polling_PULSES_X2_d_all;      /* '<Root>/POLLING_X2' */
  real_T pass_A_f;                     /* '<Root>/POLLING_X1' */
  real_T pass_B_j;                     /* '<Root>/POLLING_X1' */
  real_T Polling_PULSES_X1;            /* '<Root>/POLLING_X1' */
  real_T Polling_PULSES_X1_d_all;      /* '<Root>/POLLING_X1' */
  DW_DigitalPortRead_Encoder_T DigitalPortRead_o;/* '<S12>/Digital Port Read' */
  DW_DigitalPortRead_Encoder_T DigitalPortRead;/* '<S12>/Digital Port Read' */
} DW_Encoder_T;

/* Real-time Model Data Structure */
struct tag_RTM_Encoder_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block signals (default storage) */
extern B_Encoder_T Encoder_B;

/* Block states (default storage) */
extern DW_Encoder_T Encoder_DW;

/* Model entry point functions */
extern void Encoder_initialize(void);
extern void Encoder_step(void);
extern void Encoder_terminate(void);

/* Real-time Model object */
extern RT_MODEL_Encoder_T *const Encoder_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Encoder'
 * '<S1>'   : 'Encoder/Digital Port Read1'
 * '<S2>'   : 'Encoder/Digital Port Read2'
 * '<S3>'   : 'Encoder/Digital Port Read3'
 * '<S4>'   : 'Encoder/Digital Port Read4'
 * '<S5>'   : 'Encoder/POLLING_X1'
 * '<S6>'   : 'Encoder/POLLING_X2'
 * '<S7>'   : 'Encoder/POLLING_X4'
 * '<S8>'   : 'Encoder/X1'
 * '<S9>'   : 'Encoder/X2'
 * '<S10>'  : 'Encoder/X4'
 * '<S11>'  : 'Encoder/Digital Port Read1/ECSoC'
 * '<S12>'  : 'Encoder/Digital Port Read1/ECSoC/ECSimCodegen'
 * '<S13>'  : 'Encoder/Digital Port Read2/ECSoC'
 * '<S14>'  : 'Encoder/Digital Port Read2/ECSoC/ECSimCodegen'
 * '<S15>'  : 'Encoder/Digital Port Read3/ECSoC'
 * '<S16>'  : 'Encoder/Digital Port Read3/ECSoC/ECSimCodegen'
 * '<S17>'  : 'Encoder/Digital Port Read4/ECSoC'
 * '<S18>'  : 'Encoder/Digital Port Read4/ECSoC/ECSimCodegen'
 */
#endif                                 /* Encoder_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
