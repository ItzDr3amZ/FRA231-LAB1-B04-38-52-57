Data = out.simout1;
chunkSize = 500;  % ขนาดของแต่ละกลุ่ม
nChunks = floor(length(Data) / chunkSize);  % จำนวนกลุ่มทั้งหมด
averages = zeros(1, nChunks);  % สร้าง array เพื่อเก็บค่าเฉลี่ยแต่ละ step
schmitt = zeros(1,nChunks);
step = linspace(0,10,11);

for i = 1:nChunks
    % หา index เริ่มต้นและสิ้นสุดของแต่ละช่วง
    startIndex = (i - 1) * chunkSize + 1;
    endIndex = i * chunkSize;

    % หาค่าเฉลี่ยของแต่ละช่วงและเก็บไว้ใน averages
    averages(i) = mean(Data(startIndex:endIndex));
end
y = [0,averages];

%Plot Graph
hold on; 
plot(step,y);
title("Load Cell Lab","FontSize",16);
grid("on");
xlabel("Mass (kg)","FontSize",14);
ylabel("Vout","FontSize",14); 


%% 
%Error
err=zeros(1,11);
for j = 0:10
    Ex_force = 0.2531*j-0.02525;
    err(j+1) = Ex_force;
end
plot(step,err,'o');