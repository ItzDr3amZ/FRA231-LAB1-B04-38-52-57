/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: Encoder.c
 *
 * Code generated for Simulink model 'Encoder'.
 *
 * Model version                  : 1.115
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Fri Nov  1 03:11:17 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Encoder.h"
#include "Encoder_types.h"
#include "Encoder_private.h"
#include "rtwtypes.h"
#include "stm_timer_ll.h"

/* Block signals (default storage) */
B_Encoder_T Encoder_B;

/* Block states (default storage) */
DW_Encoder_T Encoder_DW;

/* Real-time model */
static RT_MODEL_Encoder_T Encoder_M_;
RT_MODEL_Encoder_T *const Encoder_M = &Encoder_M_;

/* Forward declaration for local functions */
static void Encoder_SystemCore_setup(stm32cube_blocks_EncoderBlock_T *obj);

/* System initialize for atomic system: */
void Encoder_DigitalPortRead_Init(DW_DigitalPortRead_Encoder_T *localDW)
{
  /* Start for MATLABSystem: '<S10>/Digital Port Read' */
  localDW->objisempty = true;
  localDW->obj.isInitialized = 1;
}

/* Output and update for atomic system: */
void Encoder_DigitalPortRead(B_DigitalPortRead_Encoder_T *localB)
{
  uint32_T pinReadLoc;

  /* MATLABSystem: '<S10>/Digital Port Read' */
  pinReadLoc = LL_GPIO_ReadInputPort(GPIOC);

  /* MATLABSystem: '<S10>/Digital Port Read' */
  localB->DigitalPortRead = ((pinReadLoc & 8192U) != 0U);
}

static void Encoder_SystemCore_setup(stm32cube_blocks_EncoderBlock_T *obj)
{
  uint8_T ChannelInfo;
  TIM_Type_T b;
  boolean_T isSlaveModeTriggerEnabled;

  /* Start for MATLABSystem: '<Root>/Encoder2' */
  obj->isInitialized = 1;
  b.PeripheralPtr = TIM3;
  b.isCenterAlignedMode = false;

  /* Start for MATLABSystem: '<Root>/Encoder2' */
  b.repetitionCounter = 0U;
  obj->TimerHandle = Timer_Handle_Init(&b);
  enableTimerInterrupts(obj->TimerHandle, 0);
  ChannelInfo = ENABLE_CH;

  /* Start for MATLABSystem: '<Root>/Encoder2' */
  enableTimerChannel1(obj->TimerHandle, ChannelInfo);
  enableTimerChannel2(obj->TimerHandle, ChannelInfo);
  isSlaveModeTriggerEnabled = isSlaveTriggerModeEnabled(obj->TimerHandle);
  if (!isSlaveModeTriggerEnabled) {
    /* Start for MATLABSystem: '<Root>/Encoder2' */
    enableCounter(obj->TimerHandle, false);
  }

  obj->isSetupComplete = true;
}

/* Model step function */
void Encoder_step(void)
{
  uint32_T pinReadLoc;
  boolean_T tmp;

  /* MATLABSystem: '<Root>/Encoder2' */
  Encoder_B.PULSES_X1 = getTimerCounterValueForG4(Encoder_DW.obj.TimerHandle,
    false, NULL);

  /* MATLABSystem: '<Root>/Encoder2' */
  ouputDirectionOfCounter(Encoder_DW.obj.TimerHandle);
  Encoder_DigitalPortRead(&Encoder_B.DigitalPortRead);

  /* MATLAB Function: '<Root>/X1' incorporates:
   *  DataTypeConversion: '<Root>/Cast To Double2'
   */
  Encoder_B.d_PULSES_X1 = (real_T)Encoder_B.PULSES_X1 - Encoder_DW.PULSES_pass;
  if (Encoder_B.d_PULSES_X1 > 32768.0) {
    Encoder_B.d_PULSES_X1 -= 65536.0;
  } else if (Encoder_B.d_PULSES_X1 < -32768.0) {
    Encoder_B.d_PULSES_X1 += 65536.0;
  }

  Encoder_DW.PULSES_ALL += Encoder_B.d_PULSES_X1;
  Encoder_B.AngularPosition_X1 = Encoder_DW.PULSES_ALL * 2.0 * 180.0;
  Encoder_B.PULSES_ALL_X1 = Encoder_DW.PULSES_ALL;
  Encoder_B.AngularVelocity_X1 = Encoder_B.AngularPosition_X1 / 0.01;
  Encoder_DW.PULSES_pass = Encoder_B.PULSES_X1;
  if (Encoder_B.DigitalPortRead.DigitalPortRead) {
    Encoder_B.d_PULSES_X1 = 0.0;
    Encoder_B.PULSES_ALL_X1 = 0.0;
    Encoder_DW.PULSES_ALL = 0.0;
  }

  /* End of MATLAB Function: '<Root>/X1' */
  /* MATLABSystem: '<S14>/Digital Port Read' */
  pinReadLoc = LL_GPIO_ReadInputPort(GPIOC);

  /* MATLABSystem: '<S14>/Digital Port Read' */
  Encoder_B.DigitalPortRead_g = ((pinReadLoc & 32U) != 0U);

  /* MATLABSystem: '<S12>/Digital Port Read' */
  pinReadLoc = LL_GPIO_ReadInputPort(GPIOC);

  /* MATLABSystem: '<S12>/Digital Port Read' */
  Encoder_B.DigitalPortRead_m = ((pinReadLoc & 16U) != 0U);
  Encoder_DigitalPortRead(&Encoder_B.DigitalPortRead_o);

  /* MATLAB Function: '<Root>/POLLING_X1' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion'
   *  DataTypeConversion: '<Root>/Data Type Conversion1'
   */
  if ((Encoder_DW.pass_A_f == 0.0) && Encoder_B.DigitalPortRead_g) {
    if ((!Encoder_B.DigitalPortRead_m) && (Encoder_DW.pass_B_j == 0.0)) {
      Encoder_DW.Polling_PULSES_X1++;
    } else if (Encoder_B.DigitalPortRead_m && (Encoder_DW.pass_B_j == 1.0)) {
      Encoder_DW.Polling_PULSES_X1--;
    }
  }

  Encoder_DW.pass_A_f = Encoder_B.DigitalPortRead_g;
  Encoder_DW.pass_B_j = Encoder_B.DigitalPortRead_m;
  Encoder_B.Polling_d_PULSES_X1 = Encoder_DW.Polling_PULSES_X1 -
    Encoder_DW.Polling_PULSES_X1_d_all;
  Encoder_DW.Polling_PULSES_X1_d_all = Encoder_DW.Polling_PULSES_X1;
  Encoder_B.Polling_AngularPosition_X1 = Encoder_DW.Polling_PULSES_X1_d_all *
    2.0 * 180.0 / 24.0;
  Encoder_B.Polling_AngularVelosity_X1 = Encoder_B.Polling_d_PULSES_X1 * 2.0 *
    180.0 / 24.0 / 0.01;
  Encoder_B.Polling_PULSES_X1_all = Encoder_DW.Polling_PULSES_X1_d_all;
  if (Encoder_B.DigitalPortRead_o.DigitalPortRead) {
    Encoder_DW.pass_A_f = 0.0;
    Encoder_DW.pass_B_j = 0.0;
    Encoder_DW.Polling_PULSES_X1 = 0.0;
    Encoder_DW.Polling_PULSES_X1_d_all = 0.0;
    Encoder_B.Polling_d_PULSES_X1 = 0.0;
    Encoder_B.Polling_PULSES_X1_all = 0.0;
    Encoder_B.Polling_AngularPosition_X1 = 0.0;
    Encoder_B.Polling_AngularVelosity_X1 = 0.0;
  }

  /* End of MATLAB Function: '<Root>/POLLING_X1' */
  /* MATLAB Function: '<Root>/POLLING_X2' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion'
   *  DataTypeConversion: '<Root>/Data Type Conversion1'
   *  MATLAB Function: '<Root>/POLLING_X4'
   */
  if ((Encoder_DW.pass_A_g == 0.0) && Encoder_B.DigitalPortRead_m) {
    if ((!Encoder_B.DigitalPortRead_g) && (Encoder_DW.pass_B_e == 0.0)) {
      Encoder_DW.Polling_PULSES_X2++;
    } else if (Encoder_B.DigitalPortRead_g && (Encoder_DW.pass_B_e == 1.0)) {
      Encoder_DW.Polling_PULSES_X2--;
    }
  }

  tmp = !Encoder_B.DigitalPortRead_m;
  if ((Encoder_DW.pass_A_g == 1.0) && tmp) {
    if (Encoder_B.DigitalPortRead_g && (Encoder_DW.pass_B_e == 1.0)) {
      Encoder_DW.Polling_PULSES_X2++;
    } else if ((!Encoder_B.DigitalPortRead_g) && (Encoder_DW.pass_B_e == 0.0)) {
      Encoder_DW.Polling_PULSES_X2--;
    }
  }

  Encoder_DW.pass_A_g = Encoder_B.DigitalPortRead_m;
  Encoder_DW.pass_B_e = Encoder_B.DigitalPortRead_g;
  Encoder_B.Polling_d_PULSES_X2 = Encoder_DW.Polling_PULSES_X2 -
    Encoder_DW.Polling_PULSES_X2_d_all;
  Encoder_DW.Polling_PULSES_X2_d_all = Encoder_DW.Polling_PULSES_X2;
  Encoder_B.Polling_AngularPosition_X2 = Encoder_DW.Polling_PULSES_X2_d_all *
    2.0 * 180.0 / 48.0;
  Encoder_B.Polling_AngularVelosity_X2 = Encoder_B.Polling_d_PULSES_X2 * 2.0 *
    180.0 / 48.0 / 0.01;
  Encoder_B.Polling_PULSES_X2_all = Encoder_DW.Polling_PULSES_X2_d_all;
  if (Encoder_B.DigitalPortRead_o.DigitalPortRead) {
    Encoder_DW.pass_A_g = 0.0;
    Encoder_DW.pass_B_e = 0.0;
    Encoder_DW.Polling_PULSES_X2 = 0.0;
    Encoder_DW.Polling_PULSES_X2_d_all = 0.0;
    Encoder_B.Polling_d_PULSES_X2 = 0.0;
    Encoder_B.Polling_PULSES_X2_all = 0.0;
    Encoder_B.Polling_AngularPosition_X2 = 0.0;
    Encoder_B.Polling_AngularVelosity_X2 = 0.0;
  }

  /* End of MATLAB Function: '<Root>/POLLING_X2' */
  /* MATLAB Function: '<Root>/POLLING_X4' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion'
   *  DataTypeConversion: '<Root>/Data Type Conversion1'
   */
  if ((Encoder_DW.pass_A == 0.0) && Encoder_B.DigitalPortRead_m) {
    if ((!Encoder_B.DigitalPortRead_g) && (Encoder_DW.pass_B == 0.0)) {
      Encoder_DW.Polling_PULSES_X4++;
    } else if (Encoder_B.DigitalPortRead_g && (Encoder_DW.pass_B == 1.0)) {
      Encoder_DW.Polling_PULSES_X4--;
    }
  }

  if ((Encoder_DW.pass_A == 1.0) && tmp) {
    if (Encoder_B.DigitalPortRead_g && (Encoder_DW.pass_B == 1.0)) {
      Encoder_DW.Polling_PULSES_X4++;
    } else if ((!Encoder_B.DigitalPortRead_g) && (Encoder_DW.pass_B == 0.0)) {
      Encoder_DW.Polling_PULSES_X4--;
    }
  }

  if ((Encoder_DW.pass_B == 0.0) && Encoder_B.DigitalPortRead_g) {
    if ((Encoder_DW.pass_A == 1.0) && Encoder_B.DigitalPortRead_m) {
      Encoder_DW.Polling_PULSES_X4++;
    } else if ((Encoder_DW.pass_A == 0.0) && tmp) {
      Encoder_DW.Polling_PULSES_X4--;
    }
  }

  if ((Encoder_DW.pass_B == 1.0) && (!Encoder_B.DigitalPortRead_g)) {
    if ((Encoder_DW.pass_A == 0.0) && tmp) {
      Encoder_DW.Polling_PULSES_X4++;
    } else if ((Encoder_DW.pass_A == 1.0) && Encoder_B.DigitalPortRead_m) {
      Encoder_DW.Polling_PULSES_X4--;
    }
  }

  Encoder_DW.pass_A = Encoder_B.DigitalPortRead_m;
  Encoder_DW.pass_B = Encoder_B.DigitalPortRead_g;
  Encoder_B.Polling_d_PULSES_X4 = Encoder_DW.Polling_PULSES_X4 -
    Encoder_DW.Polling_PULSES_X4_d_all;
  Encoder_DW.Polling_PULSES_X4_d_all = Encoder_DW.Polling_PULSES_X4;
  Encoder_B.Polling_AngularPosition_X4 = Encoder_DW.Polling_PULSES_X4_d_all *
    2.0 * 180.0 / 24.0;
  Encoder_B.Polling_AngularVelosity_X4 = Encoder_B.Polling_d_PULSES_X4 * 2.0 *
    180.0 / 24.0 / 0.01;
  Encoder_B.Polling_PULSES_X4_all = Encoder_DW.Polling_PULSES_X4_d_all;
  if (Encoder_B.DigitalPortRead_o.DigitalPortRead) {
    Encoder_DW.pass_A = 0.0;
    Encoder_DW.pass_B = 0.0;
    Encoder_DW.Polling_PULSES_X4 = 0.0;
    Encoder_DW.Polling_PULSES_X4_d_all = 0.0;
    Encoder_B.Polling_d_PULSES_X4 = 0.0;
    Encoder_B.Polling_PULSES_X4_all = 0.0;
    Encoder_B.Polling_AngularPosition_X4 = 0.0;
    Encoder_B.Polling_AngularVelosity_X4 = 0.0;
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  Encoder_M->Timing.taskTime0 =
    ((time_T)(++Encoder_M->Timing.clockTick0)) * Encoder_M->Timing.stepSize0;
}

/* Model initialize function */
void Encoder_initialize(void)
{
  /* Registration code */
  rtmSetTFinal(Encoder_M, -1);
  Encoder_M->Timing.stepSize0 = 0.01;

  /* External mode info */
  Encoder_M->Sizes.checksums[0] = (197941304U);
  Encoder_M->Sizes.checksums[1] = (3119150050U);
  Encoder_M->Sizes.checksums[2] = (3492820336U);
  Encoder_M->Sizes.checksums[3] = (3836622475U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[10];
    Encoder_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    systemRan[4] = &rtAlwaysEnabled;
    systemRan[5] = &rtAlwaysEnabled;
    systemRan[6] = &rtAlwaysEnabled;
    systemRan[7] = &rtAlwaysEnabled;
    systemRan[8] = &rtAlwaysEnabled;
    systemRan[9] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(Encoder_M->extModeInfo,
      &Encoder_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(Encoder_M->extModeInfo, Encoder_M->Sizes.checksums);
    rteiSetTPtr(Encoder_M->extModeInfo, rtmGetTPtr(Encoder_M));
  }

  /* Start for MATLABSystem: '<Root>/Encoder2' */
  Encoder_DW.obj.isInitialized = 0;
  Encoder_DW.obj.matlabCodegenIsDeleted = false;
  Encoder_SystemCore_setup(&Encoder_DW.obj);
  Encoder_DigitalPortRead_Init(&Encoder_DW.DigitalPortRead);
  Encoder_DigitalPortRead_Init(&Encoder_DW.DigitalPortRead_o);
}

/* Model terminate function */
void Encoder_terminate(void)
{
  uint8_T ChannelInfo;

  /* Terminate for MATLABSystem: '<Root>/Encoder2' */
  if (!Encoder_DW.obj.matlabCodegenIsDeleted) {
    Encoder_DW.obj.matlabCodegenIsDeleted = true;
    if ((Encoder_DW.obj.isInitialized == 1) && Encoder_DW.obj.isSetupComplete) {
      disableCounter(Encoder_DW.obj.TimerHandle);
      disableTimerInterrupts(Encoder_DW.obj.TimerHandle, 0);
      ChannelInfo = ENABLE_CH;
      disableTimerChannel1(Encoder_DW.obj.TimerHandle, ChannelInfo);
      disableTimerChannel2(Encoder_DW.obj.TimerHandle, ChannelInfo);
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/Encoder2' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
