Vq = 1650;  %half Vcc
B = zeros(1, 3301); %magnetic flux density
Sen = 0.03; %sensitivity
Stc = 0.0012;  %0.12%
Ta = 25; %ambient temp 
Step = zeros(1, 3301);
%Loop calculate magnetic flux density
for i = 0:20:3301
    keep = ((i-Vq)/(Sen*(1+Stc)))*0.001;
    B(i+1) = keep;
    Step(i+1) = i*0.001;
end

Step = Step';
err_B = 1/100*B;
%Plot Graph
hold on;
errorbar(B,Step,err_B,'or','LineWidth',1,'MarkerSize',2,'MarkerEdgeColor','r','MarkerFaceColor','r');
title("Magnetic Response Error","FontSize",16);
grid("on");
xlabel("Magnetic flux density","FontSize",14);
ylabel("Vout","FontSize",14); 


