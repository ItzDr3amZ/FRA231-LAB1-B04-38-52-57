% กำหนดชื่อไฟล์ทั้งหมดที่ต้องการโหลด
files = {'S100.mat', 'S150.mat', 'S200.mat', 'S250.mat', 'S300.mat', 'S350.mat', 'S400.mat'};
x = 1.00 : 0.5 : 4.00 ;
% สร้างตัวแปรเก็บค่าเฉลี่ย
mean_values = zeros(1, length(files));

% กำหนดช่วงเวลาที่ต้องการใช้ข้อมูล
start_time = 2;  % เวลาที่เริ่มต้น
end_time = 12;   % เวลาสิ้นสุด

% สร้างตัวแปรเก็บค่าเฉลี่ย
mean_values = zeros(1, length(files));

for i = 1:length(files)
    % โหลดข้อมูลจากแต่ละไฟล์
    data = load(files{i});
    
    % ดึงชื่อฟิลด์จาก struct และเข้าถึงข้อมูล
    field_name = fieldnames(data);
    timeseries_data = data.(field_name{1});
    
    % เลือกช่วงเวลาที่ต้องการ
    time = timeseries_data.Time;
    values = timeseries_data.Data;
    
    % กรองข้อมูลตามช่วงเวลา
    selected_values = values(time >= start_time & time <= end_time);
    
    % คำนวณค่าเฉลี่ยของข้อมูลในช่วงเวลาที่เลือก
    mean_values(i) = mean(selected_values);
end

% พลอตค่าเฉลี่ย
figure;
plot(mean_values,x);
xlabel('Distance(cm.)');
ylabel('V');
title('HALL SENSOR (South)');