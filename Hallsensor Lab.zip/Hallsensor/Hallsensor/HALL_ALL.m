% กำหนดชื่อไฟล์ทั้งหมดที่ต้องการโหลด (แบ่งเป็นกลุ่มตามชื่อ)
groups = {
    {'N100.mat', 'N150.mat', 'N200.mat', 'N250.mat', 'N300.mat', 'N350.mat', 'N400.mat'},       % Group N
    {'NS100.mat', 'NS150.mat', 'NS200.mat', 'NS250.mat', 'NS300.mat', 'NS350.mat', 'NS400.mat'}, % Group NS
    {'S100.mat', 'S150.mat', 'S200.mat', 'S250.mat', 'S300.mat', 'S350.mat', 'S400.mat'},       % Group S
    {'SS100.mat', 'SS150.mat', 'SS200.mat', 'SS250.mat', 'SS300.mat', 'SS350.mat', 'SS400.mat'} % Group SS
};


start_time = 2;  % เวลาที่เริ่มต้น
end_time = 12;   % เวลาสิ้นสุด

% สร้างตัวแปรเก็บค่าเฉลี่ยของแต่ละกลุ่ม
mean_values_N_NS = zeros(2, 7); % สำหรับกลุ่ม N และ NS มี 7 จุด
mean_values_S_SS = zeros(2, 7); % สำหรับกลุ่ม S และ SS มี 7 จุด
% N_NS_mT = zeros(2, 7) ; % สำหรับกลุ่ม N และ NS มี 7 จุด
% S_SS_mT = zeros(2, 7) ; % สำหรับกลุ่ม N และ NS มี 7 จุด
N_NS_T = zeros(2, 7) ; % สำหรับกลุ่ม N และ NS มี 7 จุด
S_SS_T = zeros(2, 7) ; % สำหรับกลุ่ม N และ NS มี 7 จุด
% ลูปผ่านแต่ละกลุ่ม
for g = 1:2
    files = groups{g};
    for i = 1:length(files)
        % โหลดข้อมูลจากแต่ละไฟล์
        data = load(files{i});
        
        % ดึงชื่อฟิลด์จาก struct และเข้าถึงข้อมูล
        field_name = fieldnames(data);
        timeseries_data = data.(field_name{1});
        
        % เลือกช่วงเวลาที่ต้องการ
        time = timeseries_data.Time;
        values = timeseries_data.Data;
        
        % กรองข้อมูลตามช่วงเวลา
        selected_values = values(time >= start_time & time <= end_time);
        
        % คำนวณค่าเฉลี่ยของข้อมูลในช่วงเวลาที่เลือก
        mean_values_N_NS(g, i) = mean(selected_values) ;

        % N_NS_mT(g, i) = ((mean(selected_values)-(3.3)/2)/30) ;
        N_NS_T(g, i) = (((mean(selected_values))-(3.3/2))/28)/1000 ;
    end
end

for g = 3:4
    files = groups{g};
    for i = 1:length(files)
        % โหลดข้อมูลจากแต่ละไฟล์
        data = load(files{i});
        
        % ดึงชื่อฟิลด์จาก struct และเข้าถึงข้อมูล
        field_name = fieldnames(data);
        timeseries_data = data.(field_name{1});
        
        % เลือกช่วงเวลาที่ต้องการ
        time = timeseries_data.Time;
        values = timeseries_data.Data;
        
        % กรองข้อมูลตามช่วงเวลา
        selected_values = values(time >= start_time & time <= end_time);
        
        % % คำนวณค่าเฉลี่ยของข้อมูลในช่วงเวลาที่เลือก
        % mean_values_S_SS(g, i) = mean(selected_values) ;
        % % S_SS_mT(g-2, i) = (mean(selected_values)-(3.3)/2)/30;
        % S_SS_T(g-2, i) = (((mean(selected_values+3.3))/2)/30)/1000;
        mean_values_S_SS(g-2, i) = mean(selected_values);
        S_SS_T(g-2, i) = ((mean(selected_values)-(3.3/2))/28)/1000;

    end
end

% พลอตค่าเฉลี่ยของทั้ง 4 กลุ่มในกราฟเดียวกัน
figure;
plot(N_NS_T(1, :), mean_values_N_NS(1, :), '-o', 'DisplayName', 'Group N'); % ครึ่งแรกของ Group N
hold on;
plot(N_NS_T(2, :), mean_values_N_NS(2, :), '-s', 'DisplayName', 'Group NS'); % ครึ่งแรกของ Group NS
hold on;
plot(S_SS_T(1, :), mean_values_S_SS(1, :), '-^', 'DisplayName', 'Group S'); % ครึ่งหลังของ Group S
hold on;
plot(S_SS_T(2, :), mean_values_S_SS(2, :), '-d', 'DisplayName', 'Group SS'); % ครึ่งหลังของ Group SS
hold off;
% 
% xlabel('Vout (V)');
% ylabel('mT');
% title('HALL SENSOR');
% legend;

 
% figure;
% plot(mean_values_N_NS(1, :),N_NS_T(1, :) , '-o', 'DisplayName', 'Group N'); % ครึ่งแรกของ Group N
% hold on;
% plot(mean_values_N_NS(2, :),N_NS_T(2, :) , '-s', 'DisplayName', 'Group NS'); % ครึ่งแรกของ Group NS
% hold on;
% plot(mean_values_S_SS(1, :), S_SS_T(1, :), '-^', 'DisplayName', 'Group S'); % ครึ่งหลังของ Group S
% hold on;
% plot(mean_values_S_SS(2, :),S_SS_T(2, :) , '-d', 'DisplayName', 'Group SS'); % ครึ่งหลังของ Group SS
% hold on;

xlabel('T');
ylabel('Vout (V)');
title('HALL SENSOR');
legend;



