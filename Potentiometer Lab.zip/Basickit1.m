%% 
Data = out.simout1;
chunkSize = 500;  % ขนาดของแต่ละกลุ่ม
nChunks = floor(length(Data) / chunkSize);  % จำนวนกลุ่มทั้งหมด
averages = zeros(1, nChunks);  % สร้าง array เพื่อเก็บค่าเฉลี่ยแต่ละ step
schmitt = zeros(1,nChunks);
step = linspace(0,100,11);

for i = 1:nChunks
    % หา index เริ่มต้นและสิ้นสุดของแต่ละช่วง
    startIndex = (i - 1) * chunkSize + 1;
    endIndex = i * chunkSize;

    % หาค่าเฉลี่ยของแต่ละช่วงและเก็บไว้ใน averages
    averages(i) = mean(Data(startIndex:endIndex));
    %schmitt trigger คอน
    if averages(i) >= 50.0 
        schmitt(i) = 1;A
    else 
        schmitt(i) = 0;
    end 
end

%แสดงค่า
disp('Averages for each chunk:');
disp(averages);
disp(schmitt);

%Plot Graph

ax_1 = subplot(1,2,1);
ax_2 = subplot(1,2,2);


plot(ax_1,step,averages);
title(ax_1,"Voltage:Rotation");
grid(ax_1,"on");
xlabel(ax_1,"Rotaional Travel");
ylabel(ax_1,"Vout/Vin*100"); 
hold on;

plot(ax_2,step,schmitt);
title(ax_2,"Schmitt Trigger");
grid(ax_2,"on");
xlabel(ax_2,"Rotaional Travel");
ylabel(ax_2,"Trigger"); 
hold off;
sgtitle("Potentiometer (B) and Schmitt trigger Lab");

%% 
% Error A
Data = Ro_A;
datasheet_RoA = Error_A;
errRoA = 20/100 * datasheet_RoA;
step = linspace(0,100,11);

chunkSize = 500;  % ขนาดของแต่ละกลุ่ม
nChunks = floor(length(Data) / chunkSize);  % จำนวนกลุ่มทั้งหมด
averages = zeros(1, nChunks);  % สร้าง array เพื่อเก็บค่าเฉลี่ยแต่ละ step
for i = 1:nChunks
    % หา index เริ่มต้นและสิ้นสุดของแต่ละช่วง
    startIndex = (i - 1) * chunkSize + 1;
    endIndex = i * chunkSize;

    % หาค่าเฉลี่ยของแต่ละช่วงและเก็บไว้ใน averages
    averages(i) = mean(Data(startIndex:endIndex));
end

%Plot Err A
hold on;
plot(step,averages,'o','MarkerSize',3,'MarkerEdgeColor','b','MarkerFaceColor','b');
errorbar(step,datasheet_RoA,errRoA','or','LineWidth',1,'MarkerSize',3,'MarkerEdgeColor','r','MarkerFaceColor','r');
hold off;
xticks(0:10:100);
xticklabels(0:10:100);
grid on;
title('Error Graph of Rotary Potentiometer A','FontSize',14);
xlabel("Rotaional Travel");
ylabel("Vout/Vin*100"); 
legend('Measured','Error Bar','Location','northwest');

%% 
% Error B
Data = Ro_B.simoutB;
datasheet_RoB = Error_B;
errRoB = 20/100 * datasheet_RoB;
step = linspace(0,100,11);

chunkSize = 500;  % ขนาดของแต่ละกลุ่ม
nChunks = floor(length(Data) / chunkSize);  % จำนวนกลุ่มทั้งหมด
averages = zeros(1, nChunks);  % สร้าง array เพื่อเก็บค่าเฉลี่ยแต่ละ step
for i = 1:nChunks
    % หา index เริ่มต้นและสิ้นสุดของแต่ละช่วง
    startIndex = (i - 1) * chunkSize + 1;
    endIndex = i * chunkSize;

    % หาค่าเฉลี่ยของแต่ละช่วงและเก็บไว้ใน averages
    averages(i) = mean(Data(startIndex:endIndex));
end

%Plot Err B
hold on;
plot(step,averages,'o','MarkerSize',3,'MarkerEdgeColor','b','MarkerFaceColor','b');
errorbar(step,datasheet_RoB,errRoB','or','LineWidth',1,'MarkerSize',3,'MarkerEdgeColor','r','MarkerFaceColor','r');
hold off;
xticks(0:10:100);
xticklabels(0:10:100);
grid on;
title('Error Graph of Rotary Potentiometer B','FontSize',14);
xlabel("Rotaional Travel");
ylabel("Vout/Vin*100"); 
legend('Measured','Error Bar','Location','northwest');

%% 
% Error C
Data = Ro_C.simoutC;
datasheet_RoC = Error_C;
errRoC = 20/100 * datasheet_RoC;
step = linspace(0,100,11);

chunkSize = 500;  % ขนาดของแต่ละกลุ่ม
nChunks = floor(length(Data) / chunkSize);  % จำนวนกลุ่มทั้งหมด
averages = zeros(1, nChunks);  % สร้าง array เพื่อเก็บค่าเฉลี่ยแต่ละ step
for i = 1:nChunks
    % หา index เริ่มต้นและสิ้นสุดของแต่ละช่วง
    startIndex = (i - 1) * chunkSize + 1;
    endIndex = i * chunkSize;

    % หาค่าเฉลี่ยของแต่ละช่วงและเก็บไว้ใน averages
    averages(i) = mean(Data(startIndex:endIndex));
end

%Plot Err C
hold on;
plot(step,averages,'o','MarkerSize',3,'MarkerEdgeColor','b','MarkerFaceColor','b');
errorbar(step,datasheet_RoC,errRoC','or','LineWidth',1,'MarkerSize',3,'MarkerEdgeColor','r','MarkerFaceColor','r');
hold off;
xticks(0:10:100);
xticklabels(0:10:100);
grid on;
title('Error Graph of Rotary Potentiometer C','FontSize',14);
xlabel("Rotaional Travel");
ylabel("Vout/Vin*100"); 
legend('Measured','Error Bar','Location','northwest');

%% 
% Error LiA (Audio)
Data = LiA;
datasheet_RoAu = Error_Audio;
errRoLiA = 20/100 * datasheet_RoAu;
step = linspace(0,100,11);

chunkSize = 500;  % ขนาดของแต่ละกลุ่ม
nChunks = floor(length(Data) / chunkSize);  % จำนวนกลุ่มทั้งหมด
averages = zeros(1, nChunks);  % สร้าง array เพื่อเก็บค่าเฉลี่ยแต่ละ step
for i = 1:nChunks
    % หา index เริ่มต้นและสิ้นสุดของแต่ละช่วง
    startIndex = (i - 1) * chunkSize + 1;
    endIndex = i * chunkSize;

    % หาค่าเฉลี่ยของแต่ละช่วงและเก็บไว้ใน averages
    averages(i) = mean(Data(startIndex:endIndex));
end

%Plot Err LiA
hold on;
plot(step,averages,'o','MarkerSize',3,'MarkerEdgeColor','b','MarkerFaceColor','b');
errorbar(step,datasheet_RoAu,errRoLiA','or','LineWidth',1,'MarkerSize',3,'MarkerEdgeColor','r','MarkerFaceColor','r');
hold off;
xticks(0:10:100);
xticklabels(0:10:100);
grid on;
title('Error Graph of Linear Potentiometer A','FontSize',14);
xlabel("Rotaional Travel");
ylabel("Vout/Vin*100"); 
legend('Measured','Error Bar','Location','northwest');

%% 
% Error LiB (Linear)
Data = LiB.simoutLiA;
datasheet_RoLi = Error_Linear;
errRoLiB = 20/100 * datasheet_RoLi;
step = linspace(0,100,11);

chunkSize = 500;  % ขนาดของแต่ละกลุ่ม
nChunks = floor(length(Data) / chunkSize);  % จำนวนกลุ่มทั้งหมด
averages = zeros(1, nChunks);  % สร้าง array เพื่อเก็บค่าเฉลี่ยแต่ละ step
for i = 1:nChunks
    % หา index เริ่มต้นและสิ้นสุดของแต่ละช่วง
    startIndex = (i - 1) * chunkSize + 1;
    endIndex = i * chunkSize;

    % หาค่าเฉลี่ยของแต่ละช่วงและเก็บไว้ใน averages
    averages(i) = mean(Data(startIndex:endIndex));
end

%Plot Err LiB
hold on;
plot(step,averages,'o','MarkerSize',3,'MarkerEdgeColor','b','MarkerFaceColor','b');
errorbar(step,datasheet_RoLi,errRoLiB','or','LineWidth',1,'MarkerSize',3,'MarkerEdgeColor','r','MarkerFaceColor','r');
hold off;
xticks(0:10:100);
xticklabels(0:10:100);
grid on;
title('Error Graph of Linear Potentiometer B','FontSize',14);
xlabel("Rotaional Travel");
ylabel("Vout/Vin*100"); 
legend('Measured','Error Bar','Location','northwest');